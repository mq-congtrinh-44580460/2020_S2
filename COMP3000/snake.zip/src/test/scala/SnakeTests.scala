/*
 * This file is part of COMP3000 Assignment 1.
 *
 * Copyright (C) 2020 Kym Haines, Macquarie University.
 * 15 Aug 20
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 *
 * Tests of the Snake puzzle solver.
 * Uses the ScalaTest `FlatSpec` style for writing tests. See
 *
 *      http://www.scalatest.org/user_guide
 *
 * For more info on writing ScalaTest tests.
 */

package org.mq.snake

import org.scalatest.FlatSpec
import org.scalatest.Matchers

class SnakeTests extends FlatSpec with Matchers {

  import CubeState._

  val st0 = OtherState(snake, toSet(List(0, 0, 0,  0, 0, 0,  0, 0, 0,
                                         1, 1, 1,  0, 0, 0,  0, 0, 0,
                                         0, 0, 0,  0, 0, 0,  0, 0, 0)),
                       (2, 1, 0), XPos, 1)

  val st1 = OtherState(snake, toSet(List(0, 0, 0,  0, 0, 0,  0, 0, 0,
                                         1, 1, 1,  1, 0, 1,  0, 0, 0,
                                         1, 0, 0,  0, 0, 0,  0, 1, 1)),
                       (0, 0, 0), YNeg, 7)

  val st2 = OtherState(snake, toSet(List(0, 0, 0,  0, 0, 0,  0, 0, 0,
                                         1, 1, 1,  0, 0, 0,  0, 0, 0,
                                         0, 0, 0,  0, 0, 0,  0, 0, 0)),
                       (2, 1, 0), XPos, 1)

  val st3 = OtherState(snake, toSet(List(1, 1, 1,  1, 1, 1,  1, 1, 1,
                                         1, 1, 1,  1, 1, 1,  1, 1, 1,
                                         1, 1, 1,  1, 1, 1,  1, 1, 1)),
                       (1, 2, 2), YPos, 17)

  val st4 = OtherState(snake, toSet(List(1, 1, 1,  1, 1, 1,  1, 1, 1,
                                         1, 1, 1,  1, 1, 1,  1, 1, 0,
                                         1, 1, 1,  1, 1, 1,  1, 1, 0)),
                       (2, 2, 2), ZPos, 16)

  val st5 = OtherState(snake, toSet(List(1, 1, 1,  1, 1, 1,  1, 1, 0,
                                         1, 1, 1,  1, 1, 1,  1, 1, 1,
                                         1, 1, 1,  1, 1, 1,  1, 1, 0)),
                       (2, 2, 1), YPos, 16)

  "Direction" should "be prepended to each sublist" in {
    assert(prependDir(XPos, List(List(YPos, ZPos), List(ZNeg))) ==
                         List(List(XPos, YPos, ZPos), List(XPos, ZNeg)))
  }

  "3D increments" should "be created for XPos" in {
    assert(getIncrement(XPos) == (1, 0, 0))
  }

  it should "be created for ZNeg" in {
    assert(getIncrement(ZNeg) == (0, 0, -1))
  }

  "getPossibleDirections" should "produce possible directions from a state" in {
    assert(getPossibleDirections(st1).toSet.equals(Set(XPos, XNeg, ZPos, ZNeg)))
  }

  it should "produce only YPos for second move" in {
    assert(getPossibleDirections(st2).toSet.equals(Set(YPos)))
  }

  "tryMove" should "work with the start state" in {
    assert(!tryMove(StartState(snake, (0, 1, 0)), XPos).isEmpty)
  }

  it should "work with the start state: end" in {
    assert(tryMove(StartState(snake, (0, 1, 0)), XPos).get.asInstanceOf[OtherState].end
              == (2, 1, 0))
  }

  it should "work with the start state: numMoves" in {
    assert(tryMove(StartState(snake, (0, 1, 0)), XPos).get.asInstanceOf[OtherState].numMoves
              == 1)
  }

  it should "work with the start state: occupied" in {
    assert(((a: Set[(Int,Int,Int)]) => (a.contains((0, 1, 0)),
                                        a.contains((1, 1, 0)),
                                        a.contains((2, 1, 0))))
       (tryMove(StartState(snake, (0, 1, 0)), XPos).get.asInstanceOf[OtherState].occupied)
              == (true, true, true))
  }

  it should "work with other state" in {
    assert(!tryMove(st0, ZPos).isEmpty)
  }

  it should "work with other state: end" in {
    assert(tryMove(st0, ZPos).get.asInstanceOf[OtherState].end
              == (2, 1, 1))
  }

  it should "work with other state: numMoves" in {
    assert(tryMove(st0, ZPos).get.asInstanceOf[OtherState].numMoves
              == 2)
  }

  it should "work with other state: occupied" in {
    assert(tryMove(st0, ZPos).get.asInstanceOf[OtherState].occupied.contains((2, 1, 1)))
  }

  "getSolutions" should "produce a list of the empty list when cube is fully occupied" in {
    assert(getSolutions(st3) == Some(List(List())))
  }

  it should "produce the final move" in {
    assert(getSolutions(st4) == Some(List(List(YNeg))))
  }

  it should "fail on the final move" in {
    assert(getSolutions(st5) == None)
  }

  // FIXME Add more tests here.
}
